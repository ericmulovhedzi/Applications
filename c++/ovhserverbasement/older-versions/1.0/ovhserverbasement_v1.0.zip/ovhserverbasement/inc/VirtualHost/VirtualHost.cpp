#include <fstream>
#include <string.h>

#include "VirtualHost.h"

VirtualHost::VirtualHost(std::string _systemName, std::string _virtualHostFolder, std::string _wwwFolder, std::string _virtualHostFile)
{
    systemName = _systemName;
    virtualHostFolder = _virtualHostFolder;
    wwwFolder = _wwwFolder;
    virtualHostFile = _virtualHostFile;
}
  
void VirtualHost::autoAppendVirtualHost(std::string ipAddress,std::string domain)
{
    std::string path = virtualHostFolder+virtualHostFile;
    VirtualHostFile.open(path.c_str(),std::ios::app); //  --- Open the file for writing, (os::app) means is for appending
    
    VirtualHostFile << "\n"
    "# ------ "+domain+" Settings - "+systemName+" \n\n"
    "<VirtualHost "+ipAddress+":80>\n"
    "        ServerName "+domain+"\n"
    "        ServerAlias www."+domain+"\n"
    "        ServerAdmin webmaster@"+domain+"\n"
    "        DocumentRoot "+wwwFolder+domain+"/public_html/\n\n"
    "        <Directory "+wwwFolder+domain+"/public_html/>\n"
    "                Options Indexes FollowSymLinks MultiViews +Includes\n"
    "                AllowOverride None\n"
    "                Order allow,deny\n"
    "                Allow from all\n"
    "        </Directory>\n"
    "</VirtualHost>\n";
    
    VirtualHostFile.close();
}
