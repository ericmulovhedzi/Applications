//#include "stdafx.h"
#include <iostream>

#include <string.h>

#include "inc/VirtualHost/VirtualHost.cpp"
#include "inc/wwwFolderStructure/wwwFolderStructure.cpp"
#include "inc/wwwHTMLPreset/wwwHTMLPreset.cpp"
#include "inc/wwwCSSPreset/wwwCSSPreset.cpp"
#include "inc/wwwJSPreset/wwwJSPreset.cpp"
#include "inc/wwwPHPPreset/wwwPHPPreset.cpp"
#include "inc/backupFolderStructure/backupFolderStructure.cpp"

using namespace std;

ofstream VirtualHostFile,HTMLFile,CSSFile,JSFile,PHPFile;
string wwwFolder,backupFolder,cronsFolder,virtualHostFolder,virtualHostFile,systemName,domain,ipAddress,email,path;
        
void Init()
{   
    systemName = "OVH Server Basement Version 1.0";
    
    //wwwFolder = "/var/www/"; // --- This is for Ubuntu Server OS
    wwwFolder="/Users/seetamatete/research/c++/ovhserverbasement/output/var/www/";
    
    //backupFolder = "/home/"; // --- This is for Ubuntu Server OS
    backupFolder = "/Users/seetamatete/research/c++/ovhserverbasement/output/home/";
    
    //cronsFolder = "/var/spool/cron/crontabs/"; // --- This is for Ubuntu Server OS
    cronsFolder="/Users/seetamatete/research/c++/ovhserverbasement/output/crons/";
    
    //virtualHostFolder="/etc/apache2/sites-available/"; // --- This is for Ubuntu Server OS
    virtualHostFolder="/Users/seetamatete/research/c++/ovhserverbasement/output/";
    virtualHostFile="default";
}

int main()
{
    char none; // --- This is simply for wizard traversal purposes
    
    cout << "Enter your IP Addess: ";cin >> ipAddress;
    cout << "Enter your Domain Name: ";cin >> domain;
    
    Init(); // Init method to initialize system default settings i.e. system name and standadrd folders
    
    // 1. ------- Update Virtual Hosts
    
    VirtualHost* _VH = new VirtualHost(systemName,virtualHostFolder,wwwFolder,virtualHostFile);
    _VH->autoAppendVirtualHost(ipAddress,domain);
    
    cout << "--- [VirtualHost] Successfully Updated, Press Yes (y) to continue: ";cin >> none; // --- Wizard Interupt
    
    // 2. ------- Create a 'www' folder structure
    
    wwwFolderStructure* _wFS = new wwwFolderStructure(wwwFolder);
    _wFS->autoCreateWWWFolders(domain);
    
    cout << "--- ['www' folder structure] Successfully created, Press Yes (y) to continue: ";cin >> none; // --- Wizard Interupt
    
    // 3. ------- Preset HTML File and auto link its Stylesheet and JavaScript
    
    wwwHTMLPreset* _wHP = new wwwHTMLPreset(systemName,wwwFolder);
    _wHP->autoPresetHTML(domain);
    
    cout << "--- [HTML Preset] Successfully created, Press Yes (y) to continue: ";cin >> none; // --- Wizard Interupt
    
    // 4. ------- Preset CSS File
    
    wwwCSSPreset* _wCP = new wwwCSSPreset(systemName,wwwFolder);
    _wCP->autoPresetCSS(domain);
    
    cout << "--- [CSS Preset] Successfully created, Press Yes (y) to continue: ";cin >> none; // --- Wizard Interupt
    
    // 5. ------- Preset JavaScript File
    
    wwwJSPreset* _wJP = new wwwJSPreset(systemName,wwwFolder);
    _wJP->autoPresetJS(domain);
    
    cout << "--- [JavaScript Preset] Successfully created Press Yes (y) to continue: ";cin >> none; // --- Wizard Interupt
    
    // 6. ------- Preset JavaScript File
    
    wwwPHPPreset* _wPP = new wwwPHPPreset(systemName,wwwFolder);
    _wPP->autoPresetPHP(domain);
    
    cout << "--- [PHP Preset] Successfully created, Press Yes (y) to continue: ";cin >> none; // --- Wizard Interupt
    
    // 7. ------- Create a 'www' folder structure
    
    backupFolderStructure* _bFS = new backupFolderStructure(backupFolder);
    _bFS->autoCreateBackupFolders(domain);
    
    // 8. ------- Update CRON JOBS
    
    /*
        To be Updated
    */
    
    cout << "Done!\n";
    
    return 0;
}