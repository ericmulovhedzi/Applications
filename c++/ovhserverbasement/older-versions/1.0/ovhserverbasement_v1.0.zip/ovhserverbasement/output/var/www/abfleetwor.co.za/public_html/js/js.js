/*!
 * OVH Server Basement Version 1.0
 * http://ovhserverbasement.co.za
 *
 * Copyright (C) 2014, OVH Server Basement Version 1.0
 * Released under the MIT, BSD, and GPL Licenses.
 *
 * Author: OVH Studio
 *
 * Tel: +27 11 071 1218
 * Email: info@ovhstudio.co.za
 * Website: www.ovhstudio.co.za
 *
 * Location: South Africa, Johannesburg
 *
 * Date: Wed May 2014
 */

// ---Start writing your JavaScript code below here:

