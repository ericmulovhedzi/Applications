<?php
/*
 ito.abifleet.co.za PHP Script
 
 OVH Server Basement Version 1.0
 http://ovhserverbasement.co.za
 
 Copyright (C) 2014, OVH Server Basement Version 1.0
 Released under the MIT, BSD, and GPL Licenses.
 
 Author: OVH Studio
 
 Tel: +27 11 071 1218
 Email: info@ovhstudio.co.za
 Website: www.ovhstudio.co.za
 
 Location: South Africa, Johannesburg
 
 Date: Wed May 2014
*/

echo "<font size='5'>Hello World..!</font><br /><br />";
echo "<font size='3'>PHP Works..!</font><br /><br />";
echo "<font size='2' color='red'>OVH Server Basement Version 1.0</font><br />";
?>
